package com.tarek360.sample;

import android.app.Application;

/**
 * Created by tarek on 10/5/16.
 */
public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}