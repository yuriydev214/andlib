(function(_ds){var window=this;'use strict';try{window.customElements.define("devsite-user",_ds.$t)}catch(a){console.warn("Unrecognized DevSite custom element - DevsiteUser",a)};})(_ds_www);
