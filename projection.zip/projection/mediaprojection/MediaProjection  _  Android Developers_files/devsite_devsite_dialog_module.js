(function(_ds){var window=this;'use strict';try{window.customElements.define("devsite-dialog",_ds.Pu)}catch(a){console.warn("devsite.app.customElement.DevsiteDialog",a)};})(_ds_www);
